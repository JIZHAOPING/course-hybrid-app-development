import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor() { }
  timer=null;
  ngOnInit() {
    this.timer=setInterval(function(){
      console.log(11);
    },1000)
  }
  ngOnDestroy(): void {
    clearInterval(this.timer);
  }
}
